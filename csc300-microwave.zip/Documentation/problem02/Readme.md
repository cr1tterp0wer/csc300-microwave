2. Using CRC cards analysis and brainstorming –

Identify, and list (with detailed description)  all the actors and use cases for the appliance, including UML diagrams. (5pts)

Perform a design step to design control software to drive the appliance. Show a set of UML diagrams that show the design elements that you have added to the system to control the device. (5pts)

Pick a specific use case scenario and completely describe it with all possible variations and alternatives. Generate a UML diagram for your use case. Draw a UML system sequence diagram for the use case and write a detailed explanation of each step in the sequence diagram.  (5pts)

Identify all the classes and operations that are active in all the use cases you have identified. Make sure to classify boundary entity and controller objects. (10pts)

Present the class diagram for your design. Include all multiplicities. (5pts)

Provide a component diagram, and a deployment diagram of the software which is used to control the appliance. (5pts)



Seth's Change 
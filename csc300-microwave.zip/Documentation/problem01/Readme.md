1. Write a set of simple system requirements for the appliance. (5pts)


Christopher's change!


3. Code your design and create a simulation of the device being used in function main. (10pts)

I'm gonna put code in here
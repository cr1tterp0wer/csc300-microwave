#include<iostream>
#include "./ToastGame/ToastGame.h"

using std::cout;
using std::endl;

int main(){
 

  ToastGame tg;
  tg.playGame();

  return 0;
}
